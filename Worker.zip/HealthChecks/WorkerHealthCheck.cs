﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using VV.SAC.CRA.Domain.Incidentes.Repositories;

namespace $safeprojectname$.HealthChecks
{
    public class WorkerHealthCheck : IHealthCheck
    {
        private IConfiguration _configurarion;

        public WorkerHealthCheck(IConfiguration configurarion)
        {
            _configurarion = configurarion;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(
            HealthCheckContext context,
            CancellationToken cancellationToken = default)
        {
            var dataUltimoProcessamento = Worker.DataUltimoProcessamentoSucesso ?? Worker.DataInicioProcessamento;
            int minutosToleranciaWorkerParado = _configurarion.GetValue<int>("IntervaloMinutosToleranciaWorkerSaudavel");
            var dataHoraValidacao = dataUltimoProcessamento.AddMinutes(minutosToleranciaWorkerParado);
            var saudavel = dataHoraValidacao >= DateTime.Now;
            return saudavel ? HealthCheckResult.Healthy() : HealthCheckResult.Unhealthy();
        }
    }
}