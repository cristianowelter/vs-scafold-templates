﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using VV.SAC.CRA.Domain.Incidentes.Repositories;

namespace $safeprojectname$.HealthChecks
{
    public class RightNowHealthCheck : IHealthCheck
    {
        private readonly IIncidenteRepository _incidenteRepository;

        public RightNowHealthCheck(IIncidenteRepository incidenteRepository)
        {
            _incidenteRepository = incidenteRepository;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(
            HealthCheckContext context,
            CancellationToken cancellationToken = default)
        {
            var saudavel = await _incidenteRepository.HealthCheck();
            return saudavel ? HealthCheckResult.Healthy() : HealthCheckResult.Unhealthy();
        }
    }
}