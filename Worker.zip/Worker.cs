﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using VV.SAC.CRA.Application.Incidentes.Services;

namespace $safeprojectname$
{
    public class Worker : BackgroundService
    {
        private static DateTime _dataInicioProcessamento;
        private readonly IConfiguration _configuration;
        private readonly ILogger<Worker> _log;
        private readonly IIncidenteService _incidenteService;

        public Worker(IConfiguration configuration, ILogger<Worker> log, IIncidenteService incidenteService)
        {
            _configuration = configuration;
            _log = log;
            _incidenteService = incidenteService;
            _dataInicioProcessamento = DateTime.Now; 
        }

        public static DateTime DataInicioProcessamento => _dataInicioProcessamento;

        public static DateTime? DataUltimoProcessamentoSucesso { get; private set; }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Delay(7500);
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    if (await _incidenteService.AtualizarPrioridadeIncidentesComOlaExpirados(stoppingToken))
                        DataUltimoProcessamentoSucesso = DateTime.Now;
                }
                catch (Exception ex)
                {
                    _log.LogError(ex, "Erro ao processar os incidentes!\nMensagem: {0}", ex.Message);
                }

                await Task.Delay(ObterIntervaloTempoMilisegundosEntreExecucoes());
            }
        }

        private int ObterIntervaloTempoMilisegundosEntreExecucoes()
        {
            return (int) TimeSpan
                .FromMinutes(_configuration.GetValue("IntervaloMinutosExecucaoWorkerIncidenteOlaExpirado", 10))
                .TotalMilliseconds;
        }
    }
}