using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Mime;
using VV.SAC.CRA.Application.Impl.Incidentes;
using VV.SAC.CRA.Application.Incidentes.Services;
using VV.SAC.CRA.Domain.Incidentes.Repositories;
using VV.SAC.CRA.HTTP.Incidentes.Repositories;
using $safeprojectname$.HealthChecks;

namespace $safeprojectname$
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            services.AddHostedService<Worker>();
            services.AddSingleton<IIncidenteService, IncidenteService>();

            services.AddHealthChecks()
                .AddCheck<RightNowHealthCheck>("RightNow")
                .AddCheck<WorkerHealthCheck>("Worker");

            services.AddHttpClient<IIncidenteRepository, IncidenteRepository>(client =>
            {
                client.BaseAddress = new Uri(_configuration.GetValue<string>("ApiRightNowUrl"));
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                client.DefaultRequestHeaders.Add("X-SecurityAccess", "External");
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Basic", _configuration.GetValue<string>("ApiRightNowToken"));
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseHealthChecks("/health", new HealthCheckOptions()
            {
                ResponseWriter = async (context, report) =>
                {
                    var result = JsonConvert.SerializeObject(
                        new
                        {
                            statusApplication = report.Status.ToString(),
                            totalDuration = report.TotalDuration,
                            healthChecks = report.Entries.Select(e => new
                            {
                                check = e.Key,
                                ErrorMessage = e.Value.Exception?.Message,
                                status = e.Value.Status.ToString(),
                                duration = e.Value.Duration
                            })
                        });
                    context.Response.ContentType = MediaTypeNames.Application.Json;
                    await context.Response.WriteAsync(result);
                }
            });
        }
    }
}